
import React,{useState,useEffect} from "react"
import axios from "axios"

export default function App(){
const [mood,setMood]=useState("")
const [list,setList]=useState([])

const load=async()=>{
const res=await axios.get("http://localhost:3001/api/moods")
setList(res.data)
}

useEffect(()=>{load()},[])

const submit=async()=>{
if(!mood)return
await axios.post("http://localhost:3001/api/moods",{mood})
setMood("")
load()
}

return(
<div style={{fontFamily:"sans-serif",padding:40}}>
<h1>MindCare+ Mood Tracker</h1>

<input value={mood} onChange={e=>setMood(e.target.value)} placeholder="How are you feeling?" />
<button onClick={submit}>Save Mood</button>

<h2>History</h2>
<ul>
{list.map(i=>(<li key={i.id}>{i.mood}</li>))}
</ul>
</div>
)
}
